<?php

include __DIR__.'/../includes/includes.php';

$tlg = new Telegram (11905966102:AAE4vraVdANRmi-k4ZLvVQDLCTVx0B93vlo);

$tlg->sendMessage ([
'GRUPO_ID' => '@itachisms2',
'text' => "<b>🤓 RECEBA SMS COM NÚMEROS NOVOS PARA CRIAR CONTAS</b>

- Telegram
- Whatsapp
- 99app
- Banqi
- Uber
- E muitos outros...

💬 Receba os códigos no nosso bot
@itachisms_bot

🌐 Canal de Referências
@itachisms
📍 Nosso grupo
@itachisms2

*Preço e serviço incomparável com os existentes.
*Mais de 4 mil números disponíveis",
'parse_mode' => 'html'
]);