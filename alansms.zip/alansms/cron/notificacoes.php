<?php

include __DIR__.'/../includes/includes.php';

$tlg = new Telegram (TOKEN_BOT);
$bd_tlg = new bdTelegram (__DIR__.'/../recebersmsbot.db');

foreach ($bd_tlg->todosUsuarios () as $usuario){

	$msg = @$tlg->sendMessage ([
		'chat_id' => $usuario ['id_telegram'],
		'text' => "😀 <b>Gere números para receber SMS no seu serviço preferido, Facebook, 99APP, Whatapp, Telegram...</b>\n\n📍É facíl, apenas recarregue sua conta com o comando /recarregar e use o saldo para comprar números, não se preocupe você só paga depois que recebe o sms!\n\n<u>Escolha um serviço para receber SMS com /servicos</u>",
		'parse_mode' => 'html'
	]);

	/*$msg = $tlg->forwardMessage ([
	 	'chat_id' => $usuario ['id_telegram'],
	 	'from_chat_id' => '@itachisms2',
	 	'message_id' => 1
	 ]);*/

	/* $msg = @$tlg->sendMessage ([
	 	'chat_id' => $usuario ['id_telegram'],
	 	'text' => "✨ Use o comando /totaladicionados para saber a quantidade de usuários que você adicionou no nosso grupo @itachisms2\n\n<u>Adicionando ".MINIMO_ADICAO." usuários você ganha R\$".number_format (BONUS_ADICAO, 2)." de saldo no bot</u>",
	 	'parse_mode' => 'html'
	 ]);*/

	if ($msg ['ok']){

		$nome = $msg ['result']['chat']['first_name'] ?? $usuario ['id'];
		echo "{$nome} enviada\n";

	}

}