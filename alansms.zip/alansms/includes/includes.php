<?php

include 'dados_bot.php';
include 'rDis.php';
include 'ApiSMS.php';
include 'SMSActivate.php';
include 'MercadoPago.php';
include 'Telegram.php';
include 'bdTelegram.php';
include 'funcoes.php';
include 'ControleProcessos.php';
include 'TelegramTools.php';