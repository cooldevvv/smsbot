<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>No momento os bots ofcs sao: @sharksmsbot",
	'parse_mode' => 'html'
]);