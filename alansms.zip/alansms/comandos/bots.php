<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>No momento os bots ofcs sao: @suleimansmsbot\n\nE o meu substituto: @suleimanzinhodelasbot",
	'parse_mode' => 'html'
]);