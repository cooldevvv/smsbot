<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>📜 · @sharksmsbot \n\n ▫️ · SUPORTE: @lowcardz</b>",
	'parse_mode' => 'html'
]);